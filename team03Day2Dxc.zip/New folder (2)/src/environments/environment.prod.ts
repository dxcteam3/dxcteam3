export const environment = {
  production: false,
  appTitle:"Integrated Banking System",
  logo:"BANK TEAM03",
  banksEndPoint:"http://localhost:6544/balCheck",
  utilityEndPoint:"http://localhost:6544/uBill",
  loginEndPoint:"http://localhost:6544/signin",
  regEndPoint:"http://localhost:6544/signup"
};