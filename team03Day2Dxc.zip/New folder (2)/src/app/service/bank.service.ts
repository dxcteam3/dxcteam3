import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../model/customer';
import { Bank } from '../model/bank';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankService {

  banksEndPoint: string;

  constructor(private client : HttpClient) {
    this.banksEndPoint = environment.banksEndPoint
   }

   showBalance(bank:Bank) : Observable<Bank> {
    return this.client.get<Bank>(this.banksEndPoint);
  }

  createAcc(bank:Bank):Observable<Bank>{
    return this.client.post<Bank>(this.banksEndPoint,bank);
  }
  
  editProfile(bank:Bank):Observable<Bank>{
    return this.client.put<Bank>(this.banksEndPoint,bank);
  }

  getByAcc(id:number):Observable<Bank>{
    return this.client.get<Bank>(`${this.banksEndPoint}/${id}`);
  }


  
}
