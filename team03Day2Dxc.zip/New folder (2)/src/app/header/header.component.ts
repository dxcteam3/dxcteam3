import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { faHome, faExchangeAlt, faUser ,faCreditCard,faCoins,faEnvelope,faScroll,faMoneyCheck,faDollarSign,faInfoCircle,faMoneyBill} from "@fortawesome/free-solid-svg-icons";
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  brand: string;
  links: any[];

  isLoggedIn: boolean;
  username: string;

  constructor(private authService: AuthService, private router: Router) {
    this.brand = environment.logo;
    this.links = [
      { icon: faHome, path: '/home', linkText: 'Home' },
      { icon: faUser, path: '/prof', linkText: 'Profile' },
      { icon: faExchangeAlt, path: '/trans', linkText: 'Transaction' },
      { icon: faCreditCard, path: '/uBill', linkText: 'Pay Utility Bill' },
      { icon: faCoins, path: '/balCheck', linkText: 'BalanceCheck' },
      { icon: faEnvelope, path: '/perio', linkText: 'Periodic statement' },
      { icon: faScroll, path: '/mini', linkText: 'Mini statement' },
      { icon: faInfoCircle, path: '/acc', linkText: 'Account Info' },
      { icon: faMoneyCheck, path: '/deposit', linkText: 'Deposit ' },
      { icon: faDollarSign, path: '/withdraw', linkText: 'WithDraw ' }

    ];
  }

  ngOnInit(): void {
    this.authService.loginStatus.subscribe(
      (status) => {
        this.isLoggedIn = status;
        if (this.isLoggedIn) {
          this.username = sessionStorage.getItem('username');
        }
      }
    );
  }


  logout() {
    this.authService.logout();
    this.router.navigateByUrl("/login");
  }

}
