export class Bank  {
 public ifsccode:number;
}
