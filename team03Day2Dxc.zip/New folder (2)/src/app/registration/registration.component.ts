import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';
import { CustomValidator } from '../validators/custom-validator';
import { faSave, faExclamationCircle } from "@fortawesome/free-solid-svg-icons";

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  regForm: FormGroup;
  errMsg: string;
  accTypes:String[];

  btnIcon = faSave;
  errIcon = faExclamationCircle;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.regForm = fb.group({
      userName: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      phoneNo: ['', Validators.required],
      adharNo: ['', Validators.required],
      address: ['', Validators.required],
      branch: ['', Validators.required],
      pinCode: ['', Validators.required],
      accType: ['', Validators.required] },
   
     {
      validators: CustomValidator.mustBeEqual('password', 'confirmPassword')
    });

    this.accTypes =["SAVING ","RDACCOUNT","FDACOUNT"];
  }

  get f() {
    return this.regForm.controls;
  }

  ngOnInit(): void {
  }

  register() {
    this.authService.register(this.regForm.value).subscribe(
      (data) => { this.router.navigateByUrl("/login") },
      (err) => {
        this.errMsg = "Sorry Unable to register. Retry later!";
        console.log(JSON.stringify(err));
      }
    );
  }

}
