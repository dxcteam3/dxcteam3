import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { faHome, faExchangeAlt, faUser ,faCreditCard,faCoins,faInfoCircle} from "@fortawesome/free-solid-svg-icons";
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  brand: string;
  links: any[];

  isLoggedIn: boolean;
  username: string;

  constructor(private authService: AuthService, private router: Router) {
    this.brand = environment.logo;
    this.links = [
      { icon: faHome, path: '/home', linkText: 'Home' },
      { icon: faUser, path: '/bank', linkText: 'Profile' },
      { icon: faExchangeAlt, path: '/trans', linkText: 'Transaction' },
      { icon: faCreditCard, path: '/utilityBill', linkText: 'Pay Utility Bill' },
      { icon: faCoins, path: '/balCheck', linkText: 'Balance and others' },
      { icon: faInfoCircle, path: '/acc', linkText: 'Account Info' }
    ];
  }

  ngOnInit(): void {
    this.authService.loginStatus.subscribe(
      (status) => {
        this.isLoggedIn = status;
        if (this.isLoggedIn) {
          this.username = sessionStorage.getItem('username');
        }
      }
    );
  }


  logout() {
    this.authService.logout();
    this.router.navigateByUrl("/login");
  }

}
