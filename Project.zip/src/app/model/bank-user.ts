export class BankUser {
    public userName:string;
    public password:string;
}
