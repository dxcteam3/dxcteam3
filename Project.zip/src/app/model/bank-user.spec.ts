import { BankUser } from './bank-user';

describe('LibraryUser', () => {
  it('should create an instance', () => {
    expect(new BankUser()).toBeTruthy();
  });
});
