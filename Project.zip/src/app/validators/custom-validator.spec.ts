import { CustomValidator } from './custom-validator';

describe('CustomValidator', () => {
  it('should create an instance', () => {
    expect(new CustomValidator()).toBeTruthy();
  });
});
