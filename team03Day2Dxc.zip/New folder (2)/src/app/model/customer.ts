import { Bank } from './bank';

export class Customer extends Bank {
    public custId:string;
    public adharNo:number;
    public userName:string;
    public password:string;
    public accNo:string;
        
}
