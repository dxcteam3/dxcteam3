import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BankService } from '../service/bank.service';
import { ActivatedRoute, Router } from '@angular/router';
import { faSave, faExclamationCircle } from "@fortawesome/free-solid-svg-icons";


@Component({
  selector: 'app-balance-check',
  templateUrl: './balance-check.component.html',
  styleUrls: ['./balance-check.component.css']
})
export class BalanceCheckComponent implements OnInit {


  balForm: FormGroup;
  errMsg: string;

  isCheck: boolean = false;

  btnIcon = faSave;
  errIcon = faExclamationCircle;

  constructor(
    private activatedRoute: ActivatedRoute,
    private bankService:BankService,
    private fb: FormBuilder,
    private router: Router) {

    this.balForm = fb.group({
      password: ['', Validators.required]
    },

    )
  }

  get f() {
    return this.balForm.controls;
  }

  ngOnInit(): void {
    let accNo = this.activatedRoute.snapshot.params.id;

    if (accNo) {
      this.bankService.getByAcc(accNo).subscribe(
        (data) => { this.balForm.setValue(data); this.isCheck=true; },
        (err) => { console.log(err.message); }
      );
    } 
  }

  balanceCheck() {
    let obr;

    if(this.isCheck){
      obr=this.bankService.showBalance(this.balForm.value);
    }else{
      obr = "no able to display balance";
    }
   
    obr.subscribe(
      (data) => { this.router.navigateByUrl("/balCheck"); },
      (err) => { console.log(err.message); }
    );
  }

}
