export class Beneficiary {
    publi
}
