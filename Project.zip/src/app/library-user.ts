export class LibraryUser {
    public userName:string;
    public password:string;
}
