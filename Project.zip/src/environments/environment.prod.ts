export const environment = {
  production: false,
  appTitle:"Integrated Banking System",
  logo:"BANK TEAM03",
  loginEndPoint:"http://localhost:6544/signin",
  regEndPoint:"http://localhost:6544/signup"
};
